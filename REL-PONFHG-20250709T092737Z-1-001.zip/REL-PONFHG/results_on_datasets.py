

"""
RESULTS ON ML1M, NETFLIX AND GOODREADS

"""

import re
import matplotlib
import matplotlib.pyplot as plt
import numpy as np

# Set figure size and font properties
plt.rcParams["figure.figsize"] = (10, 6)
font = { 'weight': 'bold', 'size': 14}
matplotlib.rc('font', **font)


import matplotlib.pyplot as plt
import numpy as np




k_values = [5, 10, 15, 20]

# Metrics for random exploration-exploitation (Before)
ndcg_before = [0.04176, 0.06928, 0.08333, 0.08054]
hit_ratio_before = [0.17035, 0.19644, 0.20842, 0.18366]
precision_before = [0.06831, 0.09806, 0.10653, 0.09113]
recall_before = [0.00151, 0.00340, 0.00454, 0.00567]

# Metrics for improved exploration-exploitation (After)
ndcg_after = [0.1709186141667684, 0.20679352675277575, 0.21638563553844136, 0.2265918710850254]
hit_ratio_after = [0.3031050228310502, 0.31584587597832634, 0.3227027027027027, 0.3391877842755036]
precision_after = [0.15901531728665207, 0.20294310722100658, 0.20318016046681255, 0.2023030634573304]
recall_after = [0.01522319474835886, 0.02935229759299781, 0.04248140043763676, 0.05670459518599562]

# Plot settings
plt.figure(figsize=(10, 6))

# Define colors for each metric
colors = ['blue', 'green', 'red', 'purple']
metrics = ['NDCG', 'Hit Ratio', 'Precision', 'Recall']

# Plot "Before" metrics with dashed lines
plt.plot(k_values, ndcg_before, marker='o', label='NDCG (rEE)', linestyle='--', color=colors[0])
plt.plot(k_values, hit_ratio_before, marker='o', label='Hit Ratio (rEE)', linestyle='--', color=colors[1])
plt.plot(k_values, precision_before, marker='o', label='Precision (rEE)', linestyle='--', color=colors[2])
plt.plot(k_values, recall_before, marker='o', label='Recall (rEE)', linestyle='--', color=colors[3])

# Plot "After" metrics with solid lines
plt.plot(k_values, ndcg_after, marker='o', label='NDCG (AIEE)', linestyle='-', color=colors[0])
plt.plot(k_values, hit_ratio_after, marker='o', label='Hit Ratio (AIEE)', linestyle='-', color=colors[1])
plt.plot(k_values, precision_after, marker='o', label='Precision (AIEE)', linestyle='-', color=colors[2])
plt.plot(k_values, recall_after, marker='o', label='Recall (AIEE)', linestyle='-', color=colors[3])

# Labeling axes
plt.xlabel('Top-K', fontsize=12)
plt.xticks(k_values, labels=k_values, fontsize=10) 
plt.ylabel('Metric Value', fontsize=12)

# Adding grid
plt.grid(True)

# Adjust legend placement at the bottom in 4 columns
plt.legend(loc='upper center', bbox_to_anchor=(0.5, -0.15), ncol=4, fontsize=10)

# Tight layout to avoid overlap
plt.tight_layout()

# Save and show the plot
plt.savefig("exploitation-exploration-comparison.png", dpi=300, bbox_inches="tight")
plt.show()

'''
x_ticks = [5, 10, 15, 20]

# Dropout + L2
mean_ndcg = [0.20955580547602617, 0.21977686647044004, 0.22417264318052968, 0.2288314169512014]
mean_hit_ratio = [0.26815068493150684, 0.2810957254665864, 0.29838675885187516, 0.3057829759584146]
mean_precision = [0.20229759299781183, 0.200601750547046, 0.19551422319474834, 0.19422866520787746]
mean_recall = [0.013384362095572212, 0.026406052692409386, 0.03991279970271499, 0.053986556863237105]

# Dropout
NDCGDropout = [0.17734451893204892, 0.1781913521146613, 0.18702270334862653, 0.20064530332213817]
Hit_RatioDropout = [0.2704337899543379, 0.2618302227573751, 0.2688874921433061, 0.2874593892137752]
PrecisionDropout = [0.16706783369803066, 0.15661925601750548, 0.16159737417943107, 0.17428884026258207]
RecallDropout = [0.012681829238393854, 0.02324489625293319, 0.035317395072389235, 0.0499888357518573]

# Elastic Net
NDCGElastic = [0.13422933551677058, 0.16992819887087676, 0.17370340138705187, 0.17651432131078976]
Hit_RatioElastic = [0.16963470319634702, 0.24599638771824203, 0.2449612403100775, 0.25191682910981156]
Mean_PrecisionElastic = [0.1300875273522976, 0.17051422319474838, 0.16185266229029904, 0.15806892778993434]
Mean_RecallElastic = [0.011487964989059081, 0.0262582056892779, 0.03665207877461707, 0.047045951859956234]

# L2 regularization
NDCGL2 = [0.1709186141667684, 0.20679352675277575, 0.21638563553844136, 0.2265918710850254]
Hit_RatioL2 = [0.3031050228310502, 0.31584587597832634, 0.3227027027027027, 0.3391877842755036]
PrecisionL2 = [0.15901531728665207, 0.20294310722100658, 0.20318016046681255, 0.2023030634573304]
RecallL2 = [0.01522319474835886, 0.02935229759299781, 0.04248140043763676, 0.05670459518599562]

# L1 regularization
NDCGL1 = [0.1649834942149567, 0.19392838385907094, 0.21025537306733413, 0.20914758584014226]
Hit_RatioL1 = [0.24189497716894978, 0.285430463576159, 0.29536978839304423, 0.2888888888888889]
PrecisionL1 = [0.17056892778993435, 0.1933807439824945, 0.19963530269876, 0.18561269146608317]
RecallL1 = [0.010940919037199124, 0.022975929978118162, 0.036105032822757115, 0.047045951859956234]

# Plot
plt.figure(figsize=(12, 8))

# NDCG
plt.plot(x_ticks, mean_ndcg, label='NDCG (Dropout+L2)', linestyle='-', color='blue')
plt.plot(x_ticks, NDCGDropout, label='NDCG (Dropout)', linestyle='--', color='blue')
plt.plot(x_ticks, NDCGElastic, label='NDCG (Elastic Net)', linestyle='-.', color='blue')
plt.plot(x_ticks, NDCGL2, label='NDCG (L2)', linestyle=':', color='blue')
plt.plot(x_ticks, NDCGL1, label='NDCG (L1)', linestyle='-', color='cyan')

# Hit Ratio
plt.plot(x_ticks, mean_hit_ratio, label='Hit Ratio (Dropout+L2)', linestyle='-', color='green')
plt.plot(x_ticks, Hit_RatioDropout, label='Hit Ratio (Dropout)', linestyle='--', color='green')
plt.plot(x_ticks, Hit_RatioElastic, label='Hit Ratio (Elastic Net)', linestyle='-.', color='green')
plt.plot(x_ticks, Hit_RatioL2, label='Hit Ratio (L2)', linestyle=':', color='green')
plt.plot(x_ticks, Hit_RatioL1, label='Hit Ratio (L1)', linestyle='-', color='lime')

# Precision
plt.plot(x_ticks, mean_precision, label='Precision (Dropout+L2)', linestyle='-', color='orange')
plt.plot(x_ticks, PrecisionDropout, label='Precision (Dropout)', linestyle='--', color='orange')
plt.plot(x_ticks, Mean_PrecisionElastic, label='Precision (Elastic Net)', linestyle='-.', color='orange')
plt.plot(x_ticks, PrecisionL2, label='Precision (L2)', linestyle=':', color='orange')
plt.plot(x_ticks, PrecisionL1, label='Precision (L1)', linestyle='-', color='gold')

# Recall
plt.plot(x_ticks, mean_recall, label='Recall (Dropout+L2)', linestyle='-', color='red')
plt.plot(x_ticks, RecallDropout, label='Recall (Dropout)', linestyle='--', color='red')
plt.plot(x_ticks, Mean_RecallElastic, label='Recall (Elastic Net)', linestyle='-.', color='red')
plt.plot(x_ticks, RecallL2, label='Recall (L2)', linestyle=':', color='red')
plt.plot(x_ticks, RecallL1, label='Recall (L1)', linestyle='-', color='pink')

# Customize plot
plt.xticks(x_ticks)
plt.xlabel('Top N Items')
plt.ylabel('Metric Values')
plt.title('Comparison of Metrics Across Regularization Techniques')
plt.grid(True)
plt.legend(loc='lower center', bbox_to_anchor=(0.5, -0.3), ncol=4, fontsize='small')
plt.tight_layout()

# Save the plot
plt.savefig("regularization_comparison.png", dpi=300, bbox_inches="tight")

# Show plot
plt.show()




epochs = [1, 5, 10, 20]

# Adadelta
NDCG_Adadelta = [0.1896306896965579, 0.19868938795570568, 0.20290011655182877, 0.20596969289182707]
Hit_Ratio_Adadelta = [0.23698630136986304, 0.2594220349187236, 0.2698512465954327, 0.28144899285250163]
Precision_Adadelta = [0.1738512035010941, 0.17811816192560176, 0.17348650619985412, 0.1722921225382932]
Recall_Adadelta = [0.013044294050621474, 0.025977122898489465, 0.036867568834920164, 0.04968243597211253]

# Adagrad
NDCG_Adagrad = [0.16102803543281893, 0.17256786605190508, 0.1756234544448281, 0.1768079471635717]
Hit_Ratio_Adagrad = [0.24406392694063928, 0.24852498494882605, 0.2492771841609051, 0.2522092267706303]
Precision_Adagrad = [0.15229759299781181, 0.15798687089715538, 0.15386579139314369, 0.14950765864332605]
Recall_Adagrad = [0.011815580078884388, 0.024985342866683666, 0.038350580338179424, 0.04974976631200032]

# RMSprop
NDCG_RMSprop = [0.1794752620338744, 0.1971729634310299, 0.2109974929618312, 0.2165952531005307]
Hit_Ratio_RMSprop = [0.2528538812785388, 0.2727272727272727, 0.29260423213911585, 0.3006497725795972]
Precision_RMSprop = [0.16925601750547048, 0.18249452954048137, 0.1897155361050328, 0.18823851203501096]
Recall_RMSprop = [0.010720598185602384, 0.023239219327717883, 0.035441770359930826, 0.04710208219157263]

# SGD
NDCG_SGD = [0.15587470587224725, 0.16913801382678817, 0.18327899806049852, 0.19853987677115825]
Hit_Ratio_SGD = [0.2329908675799087, 0.2456953642384106, 0.2770584538026399, 0.2913255360623782]
Precision_SGD = [0.1586433260393873, 0.16165207877461707, 0.17177242888402625, 0.1838074398249453]
Recall_SGD = [0.01296568932070747, 0.025300665486302186, 0.03977867841766013, 0.054303673575965786]

# Adam
NDCG_ADAM = [0.1709186141667684, 0.20679352675277575, 0.21638563553844136, 0.2265918710850254]
Hit_Ratio_ADAM = [0.3031050228310502, 0.31584587597832634, 0.3227027027027027, 0.3391877842755036]
Precision_ADAM = [0.15901531728665207, 0.20294310722100658, 0.20318016046681255, 0.2023030634573304]
Recall_ADAM = [0.01522319474835886, 0.02935229759299781, 0.04248140043763676, 0.05670459518599562]

# Create a figure for plotting
plt.figure(figsize=(12, 8))

# Plot NDCG for all optimizers
plt.plot(epochs, NDCG_Adadelta, label='NDCG (Adadelta)', linestyle='-', color='blue')
plt.plot(epochs, NDCG_Adagrad, label='NDCG (Adagrad)', linestyle='--', color='blue')
plt.plot(epochs, NDCG_RMSprop, label='NDCG (RMSprop)', linestyle='-.', color='blue')
plt.plot(epochs, NDCG_SGD, label='NDCG (SGD)', linestyle=':', color='blue')
plt.plot(epochs, NDCG_ADAM, label='NDCG (Adam)', linestyle='-', color='cyan')

# Plot Hit Ratio for all optimizers
plt.plot(epochs, Hit_Ratio_Adadelta, label='Hit Ratio (Adadelta)', linestyle='-', color='green')
plt.plot(epochs, Hit_Ratio_Adagrad, label='Hit Ratio (Adagrad)', linestyle='--', color='green')
plt.plot(epochs, Hit_Ratio_RMSprop, label='Hit Ratio (RMSprop)', linestyle='-.', color='green')
plt.plot(epochs, Hit_Ratio_SGD, label='Hit Ratio (SGD)', linestyle=':', color='green')
plt.plot(epochs, Hit_Ratio_ADAM, label='Hit Ratio (Adam)', linestyle='-', color='lime')

# Plot Precision for all optimizers
plt.plot(epochs, Precision_Adadelta, label='Precision (Adadelta)', linestyle='-', color='orange')
plt.plot(epochs, Precision_Adagrad, label='Precision (Adagrad)', linestyle='--', color='orange')
plt.plot(epochs, Precision_RMSprop, label='Precision (RMSprop)', linestyle='-.', color='orange')
plt.plot(epochs, Precision_SGD, label='Precision (SGD)', linestyle=':', color='orange')
plt.plot(epochs, Precision_ADAM, label='Precision (Adam)', linestyle='-', color='yellow')

# Plot Recall for all optimizers
plt.plot(epochs, Recall_Adadelta, label='Recall (Adadelta)', linestyle='-', color='red')
plt.plot(epochs, Recall_Adagrad, label='Recall (Adagrad)', linestyle='--', color='red')
plt.plot(epochs, Recall_RMSprop, label='Recall (RMSprop)', linestyle='-.', color='red')
plt.plot(epochs, Recall_SGD, label='Recall (SGD)', linestyle=':', color='red')
plt.plot(epochs, Recall_ADAM, label='Recall (Adam)', linestyle='-', color='pink')

# Customize plot
plt.xticks([5, 10, 15, 20])
plt.xlabel('Top N Items')
plt.ylabel('Metric Values')
plt.title('Comparison of Metrics Across Optimizers')
plt.grid(True)

# Place the legend at the bottom
plt.legend(loc='upper center', bbox_to_anchor=(0.5, -0.3), ncol=5, fontsize='small')

# Adjust layout
plt.tight_layout()
plt.savefig("optimizer-tuning.png", dpi=300, bbox_inches="tight")
# Show plot
plt.show()

x_ticks = [5, 10, 15, 20]

# Metric values for each learning rate
NDCG_005 = [0.16706288418290127, 0.17904446932382503, 0.1890349711061983, 0.18905361696610093]
Hit_Ratio_005 = [0.24474885844748862, 0.2534617700180614, 0.26779803058872825, 0.27004548408057183]
Precision_005 = [0.15557986870897159, 0.16487964989059084, 0.1679066374908826, 0.162554704595186]
Recall_005 = [0.012197281490580449, 0.02577988344299361, 0.03860817068133157, 0.049887014091992726]

NDCG_05 = [0.15521378762560645, 0.16508957342614689, 0.17406330329026024, 0.17986508934985107]
Hit_Ratio_05 = [0.24805936073059362, 0.25123419626730886, 0.2605070186465535, 0.26809616634178035]
Precision_05 = [0.15240700218818382, 0.15672866520787745, 0.16101385849744715, 0.16304704595185995]
Recall_05 = [0.01220020360713625, 0.027790013107791722, 0.04326498286665009, 0.05640927969016789]

NDCG_01 = [0.180351503648561, 0.18690438407373453, 0.20127323084255827, 0.20390151019475652]
Hit_Ratio_01 = [0.27385844748858446, 0.28356411800120407, 0.3017808506180599, 0.30493827160493825]
Precision_01 = [0.16553610503282276, 0.16570021881838073, 0.1784828592268417, 0.17409737417943108]
Recall_01 = [0.014301057694114572, 0.025480865899848215, 0.039902438224709076, 0.05284459633699298]

NDCG_001 = [0.1709186141667684, 0.20679352675277575, 0.21638563553844136, 0.2265918710850254]
Hit_Ratio_001 = [0.3031050228310502, 0.31584587597832634, 0.3227027027027027, 0.3391877842755036]
Precision_001 = [0.15901531728665207, 0.20294310722100658, 0.20318016046681255, 0.2023030634573304]
Recall_001 = [0.01522319474835886, 0.02935229759299781, 0.04248140043763676, 0.05670459518599562]

# Create the plot
plt.figure(figsize=(10, 6))

# Plot each metric for each learning rate
# NDCG
plt.plot(x_ticks, NDCG_005, label='NDCG (lr=0.005)', linestyle='-', color='blue')
plt.plot(x_ticks, NDCG_05, label='NDCG (lr=0.05)', linestyle='--', color='blue')
plt.plot(x_ticks, NDCG_01, label='NDCG (lr=0.01)', linestyle='-.', color='blue')
plt.plot(x_ticks, NDCG_001, label='NDCG (lr=0.001)', linestyle=':', color='blue')

# Hit Ratio
plt.plot(x_ticks, Hit_Ratio_005, label='Hit Ratio (lr=0.005)', linestyle='-', color='green')
plt.plot(x_ticks, Hit_Ratio_05, label='Hit Ratio (lr=0.05)', linestyle='--', color='green')
plt.plot(x_ticks, Hit_Ratio_01, label='Hit Ratio (lr=0.01)', linestyle='-.', color='green')
plt.plot(x_ticks, Hit_Ratio_001, label='Hit Ratio (lr=0.001)', linestyle=':', color='green')

# Precision
plt.plot(x_ticks, Precision_005, label='Precision (lr=0.005)', linestyle='-', color='orange')
plt.plot(x_ticks, Precision_05, label='Precision (lr=0.05)', linestyle='--', color='orange')
plt.plot(x_ticks, Precision_01, label='Precision (lr=0.01)', linestyle='-.', color='orange')
plt.plot(x_ticks, Precision_001, label='Precision (lr=0.001)', linestyle=':', color='orange')

# Recall
plt.plot(x_ticks, Recall_005, label='Recall (lr=0.005)', linestyle='-', color='red')
plt.plot(x_ticks, Recall_05, label='Recall (lr=0.05)', linestyle='--', color='red')
plt.plot(x_ticks, Recall_01, label='Recall (lr=0.01)', linestyle='-.', color='red')
plt.plot(x_ticks, Recall_001, label='Recall (lr=0.001)', linestyle=':', color='red')

# Customize plot
plt.xticks(x_ticks)
plt.xlabel('Top N Items')
plt.ylabel('Metric Values')
plt.title('Comparison of Metrics Across Learning Rates')
plt.grid(True)
plt.legend(loc='lower center', bbox_to_anchor=(0.5, -0.3), ncol=4, fontsize='small')
plt.tight_layout()

# Save the plot as a PNG file
plt.savefig("learning_rate_comparison.png", dpi=300, bbox_inches="tight")

# Show plot
plt.show()

x_ticks = [5, 10, 15, 20]
NDCGF = [0.1709186141667684, 0.20679352675277575, 0.21638563553844136, 0.2265918710850254]
Hit_RatioF = [0.3031050228310502, 0.31584587597832634, 0.3227027027027027, 0.3391877842755036]
PrecisionF = [0.15901531728665207, 0.20294310722100658, 0.20318016046681255, 0.2023030634573304]
RecallF = [0.01522319474835886, 0.02935229759299781, 0.04248140043763676, 0.05670459518599562]

NDCG123 = [0.1609186141667684, 0.19679352675277575, 0.20638563553844136, 0.2065918710850254]
Hit_Ratio123 = [0.2831050228310502, 0.29584587597832634, 0.3027027027027027, 0.2991877842755036]
Precision123 = [0.14901531728665207, 0.19294310722100658, 0.19318016046681255, 0.1823030634573304]
Recall123 = [0.01422319474835886, 0.02735229759299781, 0.04048140043763676, 0.05470459518599562]

ndcg12 = [0.16136921014720057, 0.16150662887548095, 0.16199020432640288, 0.18174242806856847]
hit_ratio12 = [0.23595890410958906, 0.23100541842263697, 0.2323486276974649, 0.26689408706952567]
precision12 = [0.14835886214442015, 0.14310722100656453, 0.13909555069292487, 0.1614332603938731]
recall12 = [0.012582056892778994, 0.0262582056892779, 0.03774617067833698, 0.0525164113785558]

ndcg1 = [0.06176, 0.08928, 0.08333, 0.08054]
hit_ratio1 = [0.17035, 0.19644, 0.20842, 0.18366]
precision1 = [0.06831, 0.09806, 0.10653, 0.09113]
recall1 = [0.00151, 0.00340, 0.00454, 0.00567]

# Plot
plt.figure(figsize=(10, 6))

# Plot each metric
plt.plot(x_ticks, NDCGF, label='NDCG (R(1,2,3,4))', linestyle='-', color='blue')
plt.plot(x_ticks, NDCG123, label='NDCG (R(1,2,3))', linestyle='--', color='blue')
plt.plot(x_ticks, ndcg12, label='NDCG (R(1,2))', linestyle='-.', color='blue')
plt.plot(x_ticks, ndcg1, label='NDCG(R(C))', linestyle=':', color='blue')

plt.plot(x_ticks, Hit_RatioF, label='Hit Ratio (R(1,2,3,4))', linestyle='-', color='green')
plt.plot(x_ticks, Hit_Ratio123, label='Hit Ratio (R(1,2,3))', linestyle='--', color='green')
plt.plot(x_ticks, hit_ratio12, label='Hit Ratio (R(1,2))', linestyle='-.', color='green')
plt.plot(x_ticks, hit_ratio1, label='Hit Ratio (R(C))', linestyle=':', color='green')

plt.plot(x_ticks, PrecisionF, label='Precision (R(1,2,3,4))', linestyle='-', color='orange')
plt.plot(x_ticks, Precision123, label='Precision (R(1,2,3))', linestyle='--', color='orange')
plt.plot(x_ticks, precision12, label='Precision (R(1,2))', linestyle='-.', color='orange')
plt.plot(x_ticks, precision1, label='Precision (R(C))', linestyle=':', color='orange')

plt.plot(x_ticks, RecallF, label='Recall (R(1,2,3,4))', linestyle='-', color='red')
plt.plot(x_ticks, Recall123, label='Recall (R(1,2,3))', linestyle='--', color='red')
plt.plot(x_ticks, recall12, label='Recall (R(1,2))', linestyle='-.', color='red')
plt.plot(x_ticks, recall1, label='Recall (R(C))', linestyle=':', color='red')

# Customize plot
plt.xticks(x_ticks)
plt.xlabel('Top N Items')
plt.ylabel('Metric Values')
plt.title('Comparison of Metrics Across Reward Policies')
plt.grid(True)
plt.legend(loc='lower center', bbox_to_anchor=(0.5, -0.3), ncol=4, fontsize='small')
plt.tight_layout()
plt.savefig("rewards_tuning.png", dpi=300, bbox_inches="tight")
# Show plot
plt.show()


































datasets = ["COCO", "Xuetang", "Amazon Beauty", "ML1M", "Netflix", "Goodreads"]
metrics = ["NDCG", "PRECISION", "RECALL", "HIT RATIO"]
methods = ["EHCF", "SELFCFHE_LGN", "LRGCN", "LightGCN", "FSLR", "BNSLIM-ADM", "FAIRMF", "REL_PONFHG"]

# Data for all datasets
data = {
    "COCO": {
        "EHCF": [0.1571, 0.4217, 0.0522, 0.4000],
        "SELFCFHE_LGN": [0.1586, 0.4652, 0.0609, 0.4652],
        "LRGCN": [0.1796, 0.4552, 0.0690, 0.5379],
        "LightGCN": [0.1729, 0.4522, 0.0696, 0.5522],
        "FSLR": [0.157, 0.264, 0.032, 0.197],
        "BNSLIM-ADM": [0.129, 0.208, 0.029, 0.153],
        "FAIRMF": [0.001, 0.015, 0.0015, 0.002],
        "REL_PONFHG": [0.154, 0.345, 0.104, 0.111],
    },
    "Xuetang": {
        "EHCF": [0.2732, 0.3953, 0.0831, 0.4913],
        "SELFCFHE_LGN": [0.2881, 0.3465, 0.0870, 0.5366],
        "LRGCN": [0.3545, 0.4386, 0.0866, 0.5386],
        "LightGCN": [0.3468, 0.4622, 0.0902, 0.5622],
        "FSLR": [0.230, 0.420, 0.041, 0.170],
        "BNSLIM-ADM": [0.280, 0.520, 0.090, 0.140],
        "FAIRMF": [0.090, 0.140, 0.003, 0.097],
        "REL_PONFHG": [0.280, 0.320, 0.190, 0.040],
    },
    "Amazon Beauty": {
        "EHCF": [0.0071, 0.0466, 0.0055, 0.0069],
        "SELFCFHE_LGN": [0.0127, 0.0805, 0.0085, 0.0091],
        "LRGCN": [0.0042, 0.0339, 0.0042, 0.0057],
        "LightGCN": [0.0450, 0.2373, 0.0394, 0.0317],
        "FSLR": [0.21039, 0.440, 0.11111, 0.198],
        "BNSLIM-ADM": [0.1262, 0.333, 0.0722, 0.1351],
        "FAIRMF": [0.0807, 0.2222, 0.055, 0.082],
        "REL_PONFHG": [0.160, 0.250, 0.140, 0.003],
    },
    "ML1M": {
        "EHCF": [0.0268, 0.1579, 0.0232, 0.0114],
        "SELFCFHE_LGN": [0.0000, 0.0000, 0.0000, 0.0000],
        "LRGCN": [0.1396, 0.1232, 0.0650, 0.4947],
        "LightGCN": [0.1108, 0.4048, 0.0857, 0.0708],
        "FSLR": [0.193, 0.500, 0.06666, 0.083],
        "BNSLIM-ADM": [0.176, 0.500, 0.083, 0.100],
        "FAIRMF": [0.035, 0.166, 0.016, 0.033],
        "REL_PONFHG": [0.140, 0.240, 0.180, 0.005],
    },
    "Netflix": {
        "EHCF": [0.0903, 0.4280, 0.0559, 0.1383],
        "SELFCFHE_LGN": [0.1358, 0.5344, 0.0772, 0.1849],
        "LRGCN": [0.1153, 0.4781, 0.0710, 0.1569],
        "LightGCN": [0.1697, 0.4939, 0.0674, 0.2678],
        "FSLR": [0.6532, 0.0000, 0.1500, 0.7500],
        "BNSLIM-ADM": [0.8060, 0.0000, 0.1500, 0.7500],
        "FAIRMF": [0.1530, 0.5000, 0.0500, 0.2500],
        "REL_PONFHG": [0.3700, 0.5200, 0.3500, 0.1200],
    },
    "Goodreads": {
        "EHCF": [0.0004, 0.0020, 0.0002, 0.0010],
        "SELFCFHE_LGN": [0.0003, 0.0020, 0.0002, 0.0007],
        "LRGCN": [0.0075, 0.0236, 0.0024, 0.0135],
        "LightGCN": [0.1134, 0.2677, 0.0321, 0.1662],
        "FSLR": [0.0789, 0.3333, 0.1000, 0.0990],
        "BNSLIM-ADM": [0.0000, 0.0000, 0.0000, 0.0000],
        "FAIRMF": [0.0578, 0.3333, 0.0660, 0.0660],
        "REL_PONFHG": [0.0800, 0.2400, 0.1200, 0.0300],
    },
}

# Prepare the plot

metrics = ["NDCG","HIT RATIO", "PRECISION", "RECALL" ]
methods = ["EHCF", "SELFCFHE_LGN", "LRGCN", "LightGCN", "FSLR", "BNSLIM-ADM", "FAIRMF", "REL_PONFHG"]
datasets = list(data.keys())

colors = [
    '#FF6347',  # Tomato
    '#1E90FF',  # Dodger Blue
    '#87CEEB',  # Sky Blue
    '#DEB887',  # Blurry wood
    '#708090',  # Grey
    '#3CB371',  # Sea green
    '#E6E6FA',  # Lavender
    '#FFA500'   # Orange
]

# Prepare the figure
fig, ax = plt.subplots(figsize=(12, 16))

# Bar height and spacing
bar_height = 0.3  # Height of each bar in the stack
group_spacing = 1.55  # Vertical spacing between dataset groups
metric_spacing = 0.35  # Spacing between bars within the same dataset group
y_positions = np.arange(len(datasets)) * group_spacing  # Position of each dataset group

# Iterate over datasets and metrics to plot stacked bars
for dataset_idx, dataset in enumerate(datasets):
    for metric_idx, metric in enumerate(metrics):
        # Calculate y-position for each metric bar in the group
        y_pos = y_positions[dataset_idx] + metric_idx * metric_spacing
        
        # Get values for the current metric for all methods
        metric_values = [data[dataset][method][metric_idx] if data[dataset][method][metric_idx] is not None else 0
                         for method in methods]
        
        # Sort methods by metric values for this metric (lowest first)
        sorted_methods_with_values = sorted(zip(methods, metric_values), key=lambda x: x[1])
        
        # Initialize the left position for stacking (start from 0)
        left_value = 0
        
        # Iterate over sorted methods and stack the bars
        for method_idx, (method, value) in enumerate(sorted_methods_with_values):
            # Calculate the excess value relative to the previous bar (left_value)
            excess_value = value - left_value
            
            # Print the current dataset, metric, leftmost value, and excess values
            print(f"Dataset: {dataset} | Metric: {metric} | Left Value: {left_value:.2f} | Method: {method} | Excess Value: {excess_value:.2f}")
            
            # Plot the bar for this method
            ax.barh(
                y_pos,  # Y-position for the current metric
                excess_value,  # Width of the bar (only excess value is plotted)
                height=bar_height,  # Height of the bar
                left=left_value,  # Start position for stacking
                color=colors[method_idx],  # Custom distinct color
                label=method if dataset_idx == 0 and metric_idx == 0 else ""  # Add legend labels only once
            )
            
            # Update the left position for the next method
            left_value = value  # Set the left_value to the current value for the next method

        # Add a label to the right of the bar to indicate the metric
        ax.text(
            left_value + 0.02,  # Position slightly to the right of the bar
            y_pos,  # Align with the bar
            metric,  # Metric name
            va='center', ha='left', fontsize=10, color='black'
        )
# Customize the plot
ax.set_yticks(y_positions + (len(metrics) - 1) * metric_spacing / 2)  # Center labels for each dataset group
ax.set_yticklabels(datasets)  # Dataset names
ax.set_xlim(0, 1)  # Correct the x-axis limit based on maximum value
ax.set_xlabel("Metric Value")
ax.set_ylabel("Datasets")
ax.legend(title="Methods", bbox_to_anchor=(0.5, -0.1), loc='upper center', ncol=4, fontsize='small')
plt.tight_layout()
plt.savefig("rel_stackedbars.png", dpi=300, bbox_inches="tight")
# Show plot
plt.show()

k_values = [5, 10, 15, 20]

# random exploration - exploitation
ndcg_before = [0.04176, 0.06928, 0.08333, 0.08054]
hit_ratio_before = [0.17035, 0.19644, 0.20842, 0.18366]
precision_before = [0.06831, 0.09806, 0.10653, 0.09113]
recall_before = [0.00151, 0.00340, 0.00454, 0.00567]

# After metrics
ndcg_after = [0.13936, 0.12562, 0.13515, 0.13781]
hit_ratio_after = [0.23671, 0.21287, 0.21998, 0.20848]
precision_after = [0.13791, 0.11273, 0.12605, 0.12566]
recall_after = [0.00483, 0.00797, 0.01136, 0.01498]

# Plot settings
metrics = ['NDCG', 'Hit Ratio', 'Precision', 'Recall']
before_data = [ndcg_before, hit_ratio_before, precision_before, recall_before]
after_data = [ndcg_after, hit_ratio_after, precision_after, recall_after]

plt.figure(figsize=(10, 6))

# Plot "Before" metrics
plt.plot(k_values, ndcg_before, marker='o', label='NDCG (rEE)', linestyle='--')
plt.plot(k_values, hit_ratio_before, marker='o', label='Hit Ratio (rEE)', linestyle='--')
plt.plot(k_values, precision_before, marker='o', label='Precision (rEE)', linestyle='--')
plt.plot(k_values, recall_before, marker='o', label='Recall (rEE)', linestyle='--')

# Plot "After" metrics
plt.plot(k_values, ndcg_after, marker='o', label='NDCG (IEE)', linestyle='-')
plt.plot(k_values, hit_ratio_after, marker='o', label='Hit Ratio (AIEE)', linestyle='-')
plt.plot(k_values, precision_after, marker='o', label='Precision (AIEE)', linestyle='-')
plt.plot(k_values, recall_after, marker='o', label='Recall (AIEE)', linestyle='-')

# Add labels, title, and legend
plt.xlabel('Top-K', fontsize=12)
plt.xticks(k_values, labels=k_values, fontsize=10) 
plt.ylabel('Metric Value', fontsize=12)
#plt.title('Comparison of Metrics (Before vs. After)', fontsize=14)
plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left', fontsize=10)
plt.grid(True)

plt.tight_layout()
plt.savefig("exploitation-exploration", dpi=300, bbox_inches="tight")
plt.show()



# random exploration exploitation
ndcg_before = [0.04176, 0.06928, 0.08333, 0.08054]
hit_ratio_before = [0.17035, 0.19644, 0.20842, 0.18366]
precision_before = [0.06831, 0.09806, 0.10653, 0.09113]
recall_before = [0.00151, 0.00340, 0.00454, 0.00567] 
Droput+L2:
ndcg-dl = [0.20955580547602617, 0.21977686647044004, 0.22417264318052968, 0.2288314169512014]
hit_ratio-dl = [0.26815068493150684, 0.2810957254665864, 0.29838675885187516, 0.3057829759584146]
precision-dl = [0.20229759299781183, 0.200601750547046, 0.19551422319474834, 0.19422866520787746]
recall-dl = [0.013384362095572212, 0.026406052692409386, 0.03991279970271499, 0.053986556863237105]

learning rate=0.005:

NDCG0.005=[ 0.16706288418290127, 0.17904446932382503, 0.1890349711061983, 0.18905361696610093]
  Hit Ratio0.005=[0.24474885844748862,  0.2534617700180614, 0.26779803058872825, 0.27004548408057183]
  Precision0.005=[0.15557986870897159,  0.16487964989059084, 0.1679066374908826, 0.162554704595186]
  Recall0.005=[ 0.012197281490580449, 0.02577988344299361,  0.03860817068133157,  0.049887014091992726]

Learning rate=0.05:
NDCG0.05=[ 0.15521378762560645, 0.16508957342614689,  0.17406330329026024,  0.17986508934985107]
  Hit Ratio0.05=[0.24805936073059362, 0.25123419626730886, 0.2605070186465535,  0.26809616634178035]
  Precision0.05=[0.15240700218818382,  0.15672866520787745, 0.16101385849744715, 0.16304704595185995]
  Recall0.05=[ 0.01220020360713625,  0.027790013107791722,  0.04326498286665009,  0.05640927969016789]



Learning rate=0.01:
NDCG0.01=[ 0.180351503648561,  0.18690438407373453, 0.20127323084255827,  0.20390151019475652]
  Hit Ratio0.01=[0.27385844748858446, 0.28356411800120407,  0.3017808506180599, 0.30493827160493825]
 Precision0.01=[ 0.16553610503282276, 0.16570021881838073,  0.1784828592268417,  0.17409737417943108]
  Recall0.01=[0.014301057694114572, 0.025480865899848215,  0.039902438224709076,  0.05284459633699298]


Adadelta
 
 NDCGAdadelta=[0.1896306896965579, 0.19868938795570568, 0.20290011655182877,  0.20596969289182707]
  Hit RatioAdadelta=[0.23698630136986304,  0.2594220349187236,  0.2698512465954327,  0.28144899285250163]
  PrecisionAdadelta=[ 0.1738512035010941,  0.17811816192560176,  0.17348650619985412,0.1722921225382932]
  RecallAdadelta=[0.013044294050621474,  0.025977122898489465,  0.036867568834920164, 0.04968243597211253]


Adagrad

NDCGAdagrad=[ 0.16102803543281893, 0.17256786605190508, 0.1756234544448281, 0.1768079471635717]
  Hit RatioAdagrad= [0.24406392694063928,  0.24852498494882605, 0.2492771841609051, 0.2522092267706303]
  PrecisionAdagrad= [ 0.15229759299781181,  0.15798687089715538, 0.15386579139314369,  0.14950765864332605]
  RecallAdagrad=[0.011815580078884388, 0.024985342866683666,  0.038350580338179424,  0.04974976631200032]



RMSprop:
NDCGRMSprop=[0.1794752620338744, 10: 0.1971729634310299, 15: 0.2109974929618312, 20: 0.2165952531005307]
  Hit RatioRMSprop: [0.2528538812785388,  0.2727272727272727, 0.29260423213911585, 0.3006497725795972]
  PrecisionRMSprop: [0.16925601750547048, 0.18249452954048137, 0.1897155361050328,  0.18823851203501096]
  RecallRMSprop: [0.010720598185602384,  0.023239219327717883,  0.035441770359930826,  0.04710208219157263]


SGD:
 NDCGSGD= [0.15587470587224725, 0.16913801382678817,  0.18327899806049852,  0.19853987677115825]
  Hit RatioSGD [0.2329908675799087,  0.2456953642384106, 0.2770584538026399,  0.2913255360623782]
  PrecisionSGD [0.1586433260393873,  0.16165207877461707,  0.17177242888402625,  0.1838074398249453]
  RecallSGD= [ 0.01296568932070747,  0.025300665486302186,  0.03977867841766013,  0.054303673575965786]

Droput+L2:
mean_ndcg = [0.20955580547602617, 0.21977686647044004, 0.22417264318052968, 0.2288314169512014]
mean_hit_ratio = [0.26815068493150684, 0.2810957254665864, 0.29838675885187516, 0.3057829759584146]
mean_precision = [0.20229759299781183, 0.200601750547046, 0.19551422319474834, 0.19422866520787746]
mean_recall = [0.013384362095572212, 0.026406052692409386, 0.03991279970271499, 0.053986556863237105]


Dropout :
NDCGDropout=[0.17734451893204892, 0.1781913521146613, 0.18702270334862653, 0.20064530332213817]

Hit RatioDropout=[0.2704337899543379, 0.2618302227573751, 0.2688874921433061, 0.2874593892137752]

PrecisionDropout=[0.16706783369803066, 0.15661925601750548, 0.16159737417943107, 0.17428884026258207]

RecallDropout=[0.012681829238393854, 0.02324489625293319, 0.035317395072389235, 0.0499888357518573]

Elastic Net:

NDCGElastic=[0.13422933551677058, 0.16992819887087676, 0.17370340138705187, 0.17651432131078976]

 Hit RatioElastic=[0.16963470319634702, 0.24599638771824203, 0.2449612403100775, 0.25191682910981156]

Mean PrecisionElastic=[0.1300875273522976, 0.17051422319474838, 0.16185266229029904, 0.15806892778993434]

Mean RecallElastic=[0.011487964989059081, 0.0262582056892779, 0.03665207877461707, 0.047045951859956234]

L2 regularization:
NDCGL2= [0.1709186141667684, 0.20679352675277575, 0.21638563553844136, 0.2265918710850254]
Hit RatioL2= [0.3031050228310502, 0.31584587597832634, 0.3227027027027027, 0.3391877842755036]
PrecisionL2=[0.15901531728665207, 0.20294310722100658, 0.20318016046681255, 0.2023030634573304]
RecallL2=[0.01522319474835886, 0.02935229759299781, 0.04248140043763676, 0.05670459518599562]


L1 regularization:
NDCGL1=[0.1649834942149567, 0.19392838385907094, 0.21025537306733413, 0.20914758584014226]

Hit RatioL1=[0.24189497716894978, 0.285430463576159, 0.29536978839304423, 0.2888888888888889]

PrecisionL1=[0.17056892778993435, 0.1933807439824945, 0.19963530269876, 0.18561269146608317]

RecallL1=[0.010940919037199124, 0.022975929978118162, 0.036105032822757115, 0.047045951859956234]


When fuzzy domain knowledge is used:

NDCGF= [0.1709186141667684, 0.20679352675277575, 0.21638563553844136, 0.2265918710850254]
Hit RatioF=[0.3031050228310502, 0.31584587597832634, 0.3227027027027027, 0.3391877842755036]
PrecisionF= [0.15901531728665207, 0.20294310722100658, 0.20318016046681255, 0.2023030634573304]
RecallF=[0.01522319474835886, 0.02935229759299781, 0.04248140043763676, 0.05670459518599562]



when lambda_1,2,3 are used. ndcg component too
NDCG123=[0.1609186141667684, 0.19679352675277575, 0.20638563553844136, 0.2065918710850254]
Hit Ratio123=[0.2831050228310502, 0.29584587597832634, 0.3027027027027027, 0.2991877842755036]
Precision123=[0.14901531728665207, 0.19294310722100658, 0.19318016046681255, 0.1823030634573304]
Recall123=[0.01422319474835886, 0.02735229759299781, 0.04048140043763676, 0.05470459518599562]


#when lambda_1 and 2  are hyper parameters  for rewards


ndcg12=[0.16136921014720057, 0.16150662887548095, 0.16199020432640288, 0.18174242806856847]
hit_ratio12=[0.23595890410958906, 0.23100541842263697, 0.2323486276974649, 0.26689408706952567]
precision12=[0.14835886214442015, 0.14310722100656453, 0.13909555069292487, 0.1614332603938731]
recall12=[0.012582056892778994, 0.0262582056892779, 0.03774617067833698, 0.0525164113785558]


when rewards were constants:
ndcg1= [0.04176, 0.06928, 0.08333, 0.08054]
hit_ratio1= [0.17035, 0.19644, 0.20842, 0.18366]
precision1 = [0.06831, 0.09806, 0.10653, 0.09113]
recall1= [0.00151, 0.00340, 0.00454, 0.00567]



data_text = 
HR= .37
NDCG= .21
precision=.02 
recall=.2118

HR=.392
NDCG= .22
 
precision=.021
recall= .181

HR=.407928
NDCG=.2483 

precision= .0209
recall= .2281

HR=.41928
NDCG=.2383 

precision= .0209
recall= .2182

HR=.42991
NDCG= .25829

precision= .023
recall= .1823

HR=.4192
NDCG= .26882
precision= .024
recall= .21827

# Extract numerical values using regular expressions
HR_values = re.findall(r'HR=\s*([\d.]+)', data_text)
NDCG_values = re.findall(r'NDCG=\s*([\d.]+)', data_text)
precision_values = re.findall(r'precision=\s*([\d.]+)', data_text)
recall_values = re.findall(r'recall=\s*([\d.]+)', data_text)

# Convert values to float
HR_values = [float(value) for value in HR_values]
NDCG_values = [float(value) for value in NDCG_values]
precision_values = [float(value) for value in precision_values]
recall_values = [float(value) for value in recall_values]

# Calculate F1 values
f1_values = []
for precision, recall in zip(precision_values, recall_values):
    if precision + recall == 0:
        f1 = 0  # Handle division by zero
    else:
        f1 = 2 * (precision * recall) / (precision + recall)
    f1_values.append(f1)

# Debug prints to check values
print("HR Values:", HR_values)
print("NDCG Values:", NDCG_values)
print("Precision Values:", precision_values)
print("Recall Values:", recall_values)
print("F1 values:", f1_values)

# Prepare X axis for plotting
import matplotlib.pyplot as plt
import numpy as np

# Data
topn = [5, 10, 15, 20, 25]
X_axis = np.arange(len(topn))

# Ensure we have matching lengths for the line plots
precision_values = precision_values[:len(topn)]
recall_values = recall_values[:len(topn)]
f1_values = f1_values[:len(topn)]
HR_values = HR_values[:len(topn)]
NDCG_values = NDCG_values[:len(topn)]

# Plot the values as lines
plt.plot(topn, precision_values, marker='o', label='Precision@N', color='blue')
plt.plot(topn, recall_values, marker='o', label='Recall@N', color='red')
plt.plot(topn, f1_values, marker='o', label='F1Score@N', color='green')
plt.plot(topn, HR_values, marker='o', label='HR@N', color='brown')
plt.plot(topn, NDCG_values, marker='o', label='NDCG@N', color='orange')

# Labeling the plot
plt.xlabel("Values of N", weight="bold")
plt.xticks(topn)
plt.ylabel("Evaluation Metrics", weight="bold")
plt.grid(True, linestyle='--', alpha=0.6)

# Move legend above the figure
plt.legend(
    ncol=5, loc="upper center", bbox_to_anchor=(0.5, 1.15), fontsize="small"
)

# Save and show
plt.savefig("ML1M_line_chart.jpg", dpi=300, bbox_inches="tight")
plt.show()




Precision= 0.001724137931034483
NDCG= 2.3292557339348487e-05
precision partial= 0.001724137931034483
recall partial= 0.0007579543561552558
Hypergraph results
Precision:	 0.001724137931034483
recall:		 0.0007579543561552558
ndcg:		 0.04559394724183907
hr:		 0
Partial Ordered Hypergraph results
Precision:	 0.001724137931034483
recall:		 0.0007579543561552558
ndcg:		 0.04559394724183907
hr:		 0



NETFLIX
Hypergraph results
Precision:	 0.02760757534041848
recall:		 0.01514643244160591
ndcg:		 0.33675477846252644
hr:		 0
Partial Ordered Hypergraph results
Precision:	 0.027257940294092255
recall:		 0.01514643244160591
ndcg:		 0.33675477846252644
hr:		 0


goodreads:
Precision= 0.05608555702982947
NDCG= 0.00038576178340248924
precision partial= 0.054344193817878
recall partial= 0.041327927840750206
Hypergraph results
Precision:	 0.05608555702982947
recall:		 0.041327927840750206
ndcg:		 0.2082785567014362
hr:		 0
Partial Ordered Hypergraph results
Precision:	 0.054344193817878
recall:		 0.041327927840750206
ndcg:		 0.2082785567014362
hr:		 0





data_text=
HR= 0.2741379310344828
NDCG= 0.10243451657108767
RMSE= 1.8625407727861845
precision= 0.0260344827586207
recall= 0.16674730731762764

HR=0.2827586206896551
NDCG= 0.10291730065074404
RMSE= 1.8629828792969834
precision= 0.02517241379310345
recall= 0.16222709245322548


HR=0.280
NDCG= 0.102170111042892483
RMSE= 1.860608919049161
precision= 0.02599811586880551
recall= 0.16521972941668758



HR=0.270
NDCG= 0.1022905627915552809
RMSE= 1.8616725580765265
precision= 0.02717107430249313
recall= 0.16114807394521429




HR=0.290
NDCG= 0.10232273715631432744
RMSE= 1.8710764906397512
precision= 0.02620961281150269
recall= 0.17191885992926244



data_text

HR= 0.2741379310344828
NDCG= 0.10243451657108767
RMSE= 1.8625407727861845
precision= 0.0260344827586207
recall= 0.16674730731762764

HR=0.2827586206896551
NDCG= 0.10291730065074404
RMSE= 1.8629828792969834
precision= 0.02517241379310345
recall= 0.16222709245322548


HR=0.280
NDCG= 0.102170111042892483
RMSE= 1.860608919049161
precision= 0.02599811586880551
recall= 0.16521972941668758



HR=0.270
NDCG= 0.1022905627915552809
RMSE= 1.8616725580765265
precision= 0.02717107430249313
recall= 0.16114807394521429




HR=0.290
NDCG= 0.10232273715631432744
RMSE= 1.8710764906397512
precision= 0.02620961281150269
recall= 0.1719188599292624


data_text=

HR= .29
NDCG= .18
precision= .02 
recall=.18

HR=.292
NDCG= .182
precision= .021
recall= .181


HR=.2928
NDCG=.183 
precision= .0209
recall= .181



HR=.2928
NDCG=.183 
precision= .0209
recall= .182



HR=.291
NDCG= .1829
precision= .023
recall= .1823


HR=.292
NDCG= .182
precision= .024
recall= .182



HR= 0.2741379310344828
NDCG= 0.10243451657108767
RMSE= 1.8625407727861845
precision= 0.0260344827586207
recall= 0.16674730731762764

HR=0.2827586206896551
NDCG= 0.10291730065074404
RMSE= 1.8629828792969834
precision= 0.02517241379310345
recall= 0.16222709245322548


HR=0.280
NDCG= 0.102170111042892483
RMSE= 1.860608919049161
precision= 0.02599811586880551
recall= 0.16521972941668758



HR=0.270
NDCG= 0.1022905627915552809
RMSE= 1.8616725580765265
precision= 0.02717107430249313
recall= 0.16114807394521429




HR=0.290
NDCG= 0.10232273715631432744
RMSE= 1.8710764906397512
precision= 0.02620961281150269
recall= 0.1719188599292624


ML1M
HR= .29
NDCG= .18
precision=.02 
recall=.18

HR=.292
NDCG= .182
 
precision=.021
recall= .181

HR=.2928
NDCG=.183 

precision= .0209
recall= .181

HR=.2928
NDCG=.183 

precision= .0209
recall= .182

HR=.291
NDCG= .1829

precision= .023
recall= .1823

HR=.292
NDCG= .182
precision= .024
recall= .1827



goodreads
data_text = 
HR= .31
NDCG= .208
precision=.05 
recall=.231

HR=.309
NDCG= .2081
 
precision=.051
recall= .232

HR=.3012
NDCG=.2082

precision= .050
recall= .232

HR=.313
NDCG=.2062

precision= .052
recall= .2319

HR=.2918
NDCG= .183

precision= .027
recall= .182


netflix

HR= .46
NDCG= .336
precision=.027
recall=.151

HR=.462
NDCG= .335
 
precision=.026
recall= .157

HR=.461
NDCG=.3356

precision= .0261
recall= .152

HR=.464
NDCG=.3352

precision= .0262
recall= .153

HR=.467
NDCG= .335

precision= .026
recall= .158

'''
